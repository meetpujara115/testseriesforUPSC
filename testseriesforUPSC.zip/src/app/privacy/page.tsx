export default function PrivacyPage(){
  return (
    <article className="prose">
      <h1>Privacy</h1>
      <p>This MVP stores your ongoing attempt and results <em>only</em> in your browser (localStorage). No server database. No tracking.</p>
    </article>
  )
}

export default function AboutPage(){
  return (
    <article className="prose">
      <h1>About</h1>
      <p><strong>testseriesforUPSC.in</strong> is a no-login, free MVP to practice UPSC PYQs and mock tests.</p>
      <p>Scoring: +2 for correct, −2/3 for wrong, 0 for unattempted. 1.5 minutes per question.</p>
    </article>
  )
}
